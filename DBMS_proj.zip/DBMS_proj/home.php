﻿<?php 
    require_once 'connection.php';
    $sql = "SELECT * FROM product";
    $all_product = $conn->query($sql);
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width-device-width, intial-scale=1:0">
    <title>flowers</title>
    <link rel="stylesheet" type="text/css" href="StyleSheet1.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <script src="Script1.js"></script>
    <script src="database.js"></script>
</head>
<body>

    <div id="first" style="display:none">
        <h1><img src="https://st2.depositphotos.com/6741230/11384/v/450/depositphotos_113843166-stock-illustration-flower-shop-logo-vector-illustration.jpg" class="logo"> WELCOME </h1> <br><br>
        <div class="login">
            <label> Username: </label>
            <input type="text" value="" id="user" placeholder="Username"></input>
            <br><br>
            <label> Password: </label>
            <input type="password" value="" id="pass" placeholder="password"></input>
            <br><br>
            <input type="button" value="Log In" class="sub" onClick="check()"></input>
            <a href="http://127.0.0.1/ch/signup.html"><input type="button" value="Create account" class="sub"></a>
        </div>
        <br><br>
    </div>
    <div id="second" >
        <header>
            <input type="checkbox" name="" id="toggler" style="display:none;">
            <label for="toggler" class="fas fa-bars"></label>
            <a href="#" class="logo"><img src="https://st2.depositphotos.com/6741230/11384/v/450/depositphotos_113843166-stock-illustration-flower-shop-logo-vector-illustration.jpg" class="logo"> </a>
            <nav class="navbar">
                <a href="#home"> HOME </a>
                <a href="#about"> ABOUT </a>
                <a href="#products"> PRODUCTS </a>
                <a href="#contact"> CONTACT </a>
            </nav>
            <div class="icons">
                <a href="#" class="fas fa-heart"> </a>
                <a href="cart.php" class="fas fa-shopping-cart"> </a>
                <a href="#" class="fas fa-user"> </a>
            </div>
        </header>
        <section class="home" id="home">
            <div class="content">
                <h3>FRESH FLOWERS</h3>
                <span> natural & beautiful flowers </span>
                <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>
                <a href="#products" class="btn"> shop now </a>
            </div>

        </section>
        <section class="about" id="about">
            <h1 class="heading"> <span> about </span> us </h1>
            <div class="row">
                <div class="video">
                    <img src="https://th.bing.com/th/id/R.31fbb0140515082c828819b8e71059b0?rik=DBLLgQLWnnBKyg&riu=http%3a%2f%2fwww.bestforbride.com%2fbridal-shop%2fwp-content%2fuploads%2f2015%2f08%2fflower-shop.jpg&ehk=knEr9PaIp1L5Rw6SrqKSqyNRTz5bScIX1UDj6vNCPgM%3d&risl=&pid=ImgRaw&r=0" id="shoppic">
                </div>
                <div class="content">
                    <h3> why choose us?</h3>
                    <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>
                    <a href="#" class="btn">learn more </a>
                </div>
            </div>
        </section>
        <section class="icons-container ">
            <div class="icons">
                <img src="https://capital-ingredients.com/wp-content/uploads/2021/02/shipping-icon.png" alt="">
                <div clss="info">
                    <h3>free delivery</h3>
                    <span>on all orders</span>
                </div>
            </div>
            <div class="icons">
                <img src="https://th.bing.com/th/id/R.6ad2c3d9edc4da818eec292283177841?rik=dSlv65NP%2bshYFA&riu=http%3a%2f%2flh3.googleusercontent.com%2f8zqF1piRraIvQHFHtW6L1jQrWHL4gqgILiamxE8lMqfPaPaUqern8WOFG_Hmdn2FNdTo0eEMcPoiSwwOqgHQPw%3ds0&ehk=2XvAr8knR46Nag%2b%2fibIodxqhzrtrtrUpUJY%2bYB7T0V4%3d&risl=&pid=ImgRaw&r=0" alt="">
                <div clss="info">
                    <h3>10 days return</h3>
                    <span>moneyback guarantee</span>
                </div>
            </div>
            <div class="icons">
                <img src="https://cdn2.iconfinder.com/data/icons/simple-line-vol4/100/_-5-256.png" alt="">
                <div clss="info">
                    <h3>offers and gifts</h3>
                    <span>on all orders</span>
                </div>
            </div>
            <div class="icons">
                <img src="https://static.vecteezy.com/system/resources/previews/000/574/730/original/credit-card-icon-vector.jpg" alt="">
                <div clss="info">
                    <h3>secure payments</h3>
                    <span>COD availaible</span>
                </div>
            </div>
        </section>
        <section class="products" id="products">
            <h1 class="heading">
                latest <span>products</span>
            </h1>
            <div class="box-container">
            <?php
                while($row= mysqli_fetch_assoc($all_product) ) {
            ?>
                <div class="box">
                    <div class="image">
                        <img src= "<?php echo $row["product_image"]; ?>" alt="">
                        <div class="icons">
                            <!--<button class="fas fa-heart"></button>
                            <button class="cart-btn" data-id="">add to cart</button>
                            <button class="fas fa-share shareButton"></button>-->
                            <form action="cart_test.php" method="post">
                               
                                <input type="text" name="pid" value="<?php echo $row["product_name"]; ?>" style="display:none;">
                                <input type="text" name="qty" placeholder="qty">

                            <input type="submit" name="save" value="addtocart">
                            </form>

                            
                        </div>
                    </div>
                    <div class="content">
                        <h3 > <?php echo $row["product_name"]; ?> </h3>
                        <div class="price">Rs.<?php echo $row["price"]; ?> <span>Rs<?php echo $row["discount"]; ?></span></div>
                    </div>
                </div>
                <?php
                } 
                ?>
                <!-- <div class="box">
                    <div class="image">
                        <img src="https://th.bing.com/th/id/OIP.nHnIDwGZNoCbHPp8qfZXmwAAAA?pid=ImgDet&rs=1" alt="">
                        <div class="icons">
                            <button class="fas fa-heart"></button>
                            <button class="cart-btn">add to cart</button>
                            <button class="fas fa-share shareButton"></button>
                        </div>
                    </div>
                    <div class="content">
                        <h3>White orchid</h3>
                        <div class="price">Rs.13<span>Rs25</span></div>
                    </div>
                </div>

                <div class="box">
                    <div class="image">
                        <img src="https://www.manilagrocerystore.com/images/detaile d/7/15-Red-Tulips-Bouquet.jpg" alt="">
                        <div class="icons">
                            <button class="fas fa-heart"></button>
                            <button class="cart-btn">add to cart</button>
                            <button class="fas fa-share shareButton"></button>
                        </div>
                    </div>
                    <div class="content">
                        <h3>Rose</h3>
                        <div class="price">Rs.10<span>Rs15</span></div>
                    </div>
                </div>

                <div class="box">
                    <div class="image">
                        <img src="https://www.flowerchix.com/wp-content/uploads/2021/06/5.jpg" alt="">
                        <div class="icons">
                            <button class="fas fa-heart"></button>
                            <button class="cart-btn">add to cart</button>
                            <button class="fas fa-share shareButton"></button>
                        </div>
                    </div>
                    <div class="content">
                        <h3>Lily</h3>
                        <div class="price">Rs.18<span>Rs25</span></div>
                    </div>
                </div>

                <div class="box">
                    <div class="image">
                        <img src="https://th.bing.com/th/id/OIP.DSTbzyO_L1P1d4IGoSG5jQHaHa?pid=ImgDet&w=1500&h=1500&rs=1" alt="">
                        <div class="icons">
                            <button class="fas fa-heart"></button>
                            <button class="cart-btn">add to cart</button>
                            <button class="fas fa-share shareButton"></button>
                        </div>
                    </div>
                    <div class="content">
                        <h3>Mixed gerbara </h3>
                        <div class="price">Rs.499<span>Rs999</span></div>
                    </div>
                </div>

                <div class="box">
                    <div class="image">
                        <img src="https://www.fnp.com/images/pr/l/v20210718121548/mesmerising-blue-orchids-bouquet_1.jpg" alt="">
                        <div class="icons">
                            <button class="fas fa-heart"></button>
                            <button class="cart-btn">add to cart</button>
                            <button class="fas fa-share shareButton"></button>
                        </div>
                    </div>
                    <div class="content">
                        <h3>Blue orchids boquet</h3>
                        <div class="price">Rs.499<span>Rs799</span></div>
                    </div>
                </div>
                <div class="box">
                    <div class="image">
                        <img src="https://th.bing.com/th/id/OIP.6we9MtRlAOJklAPwoazm8QHaGI?pid=ImgDet&rs=1" alt="">
                        <div class="icons">
                            <button class="fas fa-heart"></button>
                            <button class="cart-btn">add to cart</button>
                            <button class="fas fa-share shareButton"></button>
                        </div>
                    </div>
                    <div class="content">
                        <h3>Lavender</h3>
                        <div class="price">Rs.25<span>Rs45</span></div>
                    </div>
                </div>
                <div class="box">
                    <div class="image">
                        <img src="https://www.fnp.com/images/pr/l/v20230127224743/garden-of-glory-florals-vase_1.jpg" alt="">
                        <div class="icons">
                            <button class="fas fa-heart"></button>
                            <button class="cart-btn">add to cart</button>
                            <button class="fas fa-share shareButton"></button>
                        </div>
                    </div>
                    <div class="content">
                        <h3>Garden Florals Vase</h3>
                        <div class="price">Rs.499<span>Rs1949</span></div>
                    </div>
                </div>
                <div class="box">
                    <div class="image">
                        <img src="https://www.fnp.com/images/pr/l/v20220204210632/10-romantic-red-roses-bouquet_1.jpg" alt="">
                        <div class="icons">
                            <button class="fas fa-heart"></button>
                            <button class="cart-btn">add to cart</button>
                            <button class="fas fa-share shareButton"></button>
                        </div>
                    </div>
                    <div class="content">
                        <h3>Red roses bouquet</h3>
                        <div class="price">Rs.499<span>Rs1949</span></div>
                    </div>
                </div> -->
            </div>

        </section>
        <section class="contact" id="contact">
            <h1 class="heading"><span>contact</span>us</h1>
            <div class="row">
                <form action="">
                    <input type="text" placeholder="name" class="box">
                    <input type="email" placeholder="email" class="box">
                    <input type="number" placeholder="number" class="box">
                    <textarea name="" class="box" placeholder="message" id="" cols="30" rows="10"> </textarea>
                    <input type="submit" value="send message" class="btn">
                </form>
                <div class="image">
                    <img src="https://media.istockphoto.com/vectors/young-woman-sprays-houseplants-vector-id1248158272?k=6&m=1248158272&s=612x612&w=0&h=bcOj6qVSJKNvQrTsFKV56PUNcQyBESPTrM11fS98QH0=" alt="">
                </div> <br>
                </div>
        </section>
        <section class="footer">
            <div class="box-container">
                <div class="box">
                    <h3>quick links</h3>
                    <a href="#home">home</a>
                    <a href="#about">about</a>
                    <a href="#products">products</a>
                    <a href="#contact">contact</a>
                </div>
                <div class="box">
                    <h3>extra links</h3>
                    <a href="#">my account</a>
                    <a href="#about">my favorites</a>
                </div>
                <div class="box">
                    <h3>locations</h3>
                    <a href="#">Chennai</a>
                    <a href="#">Mumbai</a>
                    <a href="#">Bangalore</a>
                </div>
                <div class="box">
                    <h3>contact info</h3>
                    <a href="#">044 24638220</a>
                    <a href="#">floral@gmail.com</a>
                    <a href="#">besant nagar,Chennai-600090</a>
                    <img src="https://killercovers.com/wp-content/uploads/2017/12/Credit-Cards-150x17.png" alt="">
                </div>
            </div>
        </section>
    </div>
<script>
    var product_id= document.getElementsByClassName("cart-btn");
    for(var i=0; i<product_id.length; i++) {
        product_id[i].addEventListener("click",function(event){
            var target = event.target;
            var id=target.getAttribute("data-id");
            var xml= new XMLHttpRequest();
            xml.onreadystatechange = function() {
                if(this.readyState == 4 && this.status == 200) {
                    var data = JSON.parse(this.responseText);
                    target.innerHTML=data.in_cart;
                }
            }

            xml.open("GET","connection.php?id="+id,true);
            xml.send();

        }) 
    }
</script>
</body>
</html> 
