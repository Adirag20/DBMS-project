<?php
$server_name="localhost:4306";
$username="root";
$password="";
$database_name="addtocart";
$conn= new mysqli($server_name,$username,$password,$database_name);


if(isset($_POST['del']))
{
	$pname=$_POST['product_name'];
	$sql_query="DELETE FROM cart WHERE product_id='$pname'";
    
	if(mysqli_query($conn, $sql_query))
	{
		header("Location: cart.php");
	}
	else
	{
		echo "Error: " . $sql . "" . mysqli_error($conn);
	}
	
	mysqli_close($conn);
}


/*$conn=mysqli_connect($server_name,$username,$password,$database_name);
if(!$conn)
{
	die("connection failed:" . mysqli_connect_error());

}
else{

    require_once 'connection.php';
    $sql = "SELECT * FROM flowers"


}*/
?>