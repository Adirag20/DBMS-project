<?php
$server_name="localhost:4306";
$username="root";
$password="";
$database_name="addtocart";
$conn=mysqli_connect($server_name,$username,$password,$database_name);
if(!$conn)
{
	die("connection failed:" . mysqli_connect_error());

}
if(isset($_POST['save']))
{
	$username=$_POST['username'];
	$email=$_POST['email'];
	$password=$_POST['password'];

	$sql_query="INSERT INTO users (username, email, password)
	VALUES ('$username','$email','$password')";
	
	if(mysqli_query($conn, $sql_query))
	{
		header("Location: home.php");
	}
	else
	{
		echo "Error: " . $sql . "" . mysqli_error($conn);
	}
	mysqli_close($conn);
}
?>