<?php
$server_name="localhost:4306";
$username="root";
$password="";
$database_name="addtocart";
$conn=mysqli_connect($server_name,$username,$password,$database_name);
if(!$conn)
{
	die("connection failed:" . mysqli_connect_error());

}
if(isset($_POST['save']))
{
	$pid=$_POST['pid'];
	$qty=$_POST['qty'];
	$sql_query="INSERT INTO cart (product_id,qty)
	VALUES ('$pid',$qty)";
    
	if(mysqli_query($conn, $sql_query))
	{
		header("Location: cart.php");
	}
	else
	{
		echo "Error: " . $sql . "" . mysqli_error($conn);
	}
	
	mysqli_close($conn);
}
?>