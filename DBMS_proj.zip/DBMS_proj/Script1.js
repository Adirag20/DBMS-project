// JavaScript source code
function check() {
    let us = document.getElementById("user").value;
    let ps = document.getElementById("pass").value;
    if (us == "Tushar" && ps == "123" || us=="" && ps=="" || us=="dbms" && ps=="test") {
        document.getElementById('first').style.display = 'none';
        document.getElementById('second').style.display = 'block';
    }
    else {
        alert("Incorrect username or password");
    }
}
const shareButtons = document.querySelectorAll(".shareButton");

shareButtons.forEach(function (button) {
    button.addEventListener("click", function () {
        const url = window.location.href;
        navigator.clipboard.writeText(url)
            .then(function () {
                console.log("URL copied to clipboard:", url);
                alert("URL copied to clipboard!");
            })
            .catch(function (error) {
                console.error("Error copying URL to clipboard:", error);
                alert("Failed to copy URL to clipboard. Please copy it manually.");
            });
    });
});
